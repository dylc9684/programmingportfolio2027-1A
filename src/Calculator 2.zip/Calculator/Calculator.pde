// ldyan cheng | Sept 14 2026 | Calculator
String displayVal;
float l, r, result;
char op;
boolean left;
boolean newEntry;

float savedL = 0.0;
char savedOp = ' ';
boolean hasParenthesis = false;

Button[] numButtons = new Button[10];
Button[] opButtons = new Button[12];

String displayValue = "0";

void setup() {

  size(300, 400);
  displayVal = "0.0";
  l = 0.0;
  r = 0.0;
  result = 0.0;
  op = ' ';
  left = true;
  newEntry = true;

  numButtons[0] = new Button(50, 350, '0');
  numButtons[1] = new Button(50, 300, '1');
  numButtons[2] = new Button(110, 300, '2');
  numButtons[3] = new Button(170, 300, '3');
  numButtons[4] = new Button(50, 240, '4');
  numButtons[5] = new Button(110, 240, '5');
  numButtons[6] = new Button(170, 240, '6');
  numButtons[7] = new Button(50, 180, '7');
  numButtons[8] = new Button(110, 180, '8');
  numButtons[9] = new Button(170, 180, '9');

  opButtons[0] = new Button(230, 180, '+');
  opButtons[1] = new Button(230, 240, '-');
  opButtons[2] = new Button(230, 300, '*');
  opButtons[3] = new Button(230, 350, '/');
  opButtons[4] = new Button(170, 350, '=');
  opButtons[5] = new Button(50, 120, 'C');
  opButtons[6] = new Button(110, 350, '.');
  opButtons[7] = new Button(110, 120, '%');
  opButtons[8] = new Button(170, 120, '^');
  opButtons[9] = new Button(230, 120, '±');
  opButtons[10] = new Button(35, 30, '(');
  opButtons[11] = new Button(35, 75, ')');
}

void draw() {
  background(#1E1E24);
  updateDisplay();
  for (int i = 0; i < numButtons.length; i++) {
    numButtons[i].display();
    numButtons[i].mouseOver(mouseX, mouseY);
  }
  for (int i = 0; i < opButtons.length; i++) {
    opButtons[i].display();
    opButtons[i].mouseOver(mouseX, mouseY);
  }
}

void updateDisplay() {
  rectMode(CENTER);
  fill(#FFFFFF);
  rect(180, 50, 200, 50, 100);

  fill(0);
  textAlign(RIGHT);
  text(displayVal, 250, 50);
}

void mouseReleased() {
  for (int i = 0; i < numButtons.length; i++) {
    if (numButtons[i].hover) {
      String digit = str(numButtons[i].val);

      if (newEntry || displayVal.equals("0.0") || displayVal.equals("0")) {
        displayVal = digit;
        newEntry = false;
      } else {
        displayVal += digit;
      }

      if (left) {
        l = float(displayVal);
      } else {
        r = float(displayVal);
      }
    }
  }

  for (int i = 0; i < opButtons.length; i++) {
    if (opButtons[i].hover) {
      char clicked = opButtons[i].val;

      if (clicked == '=') {
        performCalc();
      } else if (clicked == '+' || clicked == '-' || clicked == '*' || clicked == '/' || clicked == '%' || clicked == '^') {
        op = clicked;
        left = false;
        newEntry = true;
        displayVal = str(op);
      } else if (clicked == '±') {
        toggleSign();
      } else if (clicked == '(') {
        savedL = left ? l : r;
        savedOp = op;
        l = 0.0;
        r = 0.0;
        op = ' ';
        left = true;
        newEntry = true;
        hasParenthesis = true;
        displayVal = "(";
      } else if (clicked == ')') {
        if (hasParenthesis) {
          if (op != ' ') {
            performCalc();
          }
          float subResult = l;
          if (savedOp != ' ') {
            l = savedL;
            op = savedOp;
            r = subResult;
            left = false;
          } else {
            l = subResult;
            op = ' ';
            r = 0.0;
            left = true;
          }
          newEntry = true;
          hasParenthesis = false;
          displayVal = str(subResult);
        }
      } else if (clicked == 'C') {
        displayVal = "0.0";
        l = 0.0;
        r = 0.0;
        result = 0.0;
        op = ' ';
        left = true;
        newEntry = true;
        hasParenthesis = false;
      } else if (clicked == '.') {
        if (!displayVal.contains(".")) {
          displayVal += ".";
          if (left) {
            l = float(displayVal);
          } else {
            r = float(displayVal);
          }
        }
      }
    }
  }
}

void toggleSign() {
  if (left) {
    l = -l;
    displayVal = str(l);
  } else {
    r = -r;
    displayVal = str(r);
  }
}

void performCalc() {
  if (op == '+') {
    result = l + r;
  } else if (op == '-') {
    result = l - r;
  } else if (op == '/') {
    if (r == 0) {
      displayVal = "ERROR";
      newEntry = true;
      return;
    }
    result = l / r;
  } else if (op == '*') {
    result = l * r;
  } else if (op == '%') {
    result = l % r;
  } else if (op == '^') {
    result = pow(l, r);
  } else {
    return;
  }

  displayVal = str(result);
  l = result;
  r = 0.0;
  left = true;
  newEntry = true;
}
